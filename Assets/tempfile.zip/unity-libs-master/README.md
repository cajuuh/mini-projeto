# unity-libs
This repository contains the Unity3D libraries for reference usage in mono csharp solutions.
They can be found at your Unity3D installation path and got extracted for continuous integration purposes.
